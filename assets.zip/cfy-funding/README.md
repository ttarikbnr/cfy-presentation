
## How to Use Lean  Canvas Builder

1.  Load dependencies
```
npm install
```

2. Create your canvas e.finitions file b. copying from the template
```
cp lean-canvas-tmpl.json your-name.json
```

3. Prepore canvas content b. edititng your-name.json file

4. Build your canvas document
```
node build.js your-name.js
```